package com.bedu.inventario2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Inventario2Application {

	public static void main(String[] args) {
		SpringApplication.run(Inventario2Application.class, args);
	}

}
