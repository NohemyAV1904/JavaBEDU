package com.bedu.inventario2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Inventario2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
